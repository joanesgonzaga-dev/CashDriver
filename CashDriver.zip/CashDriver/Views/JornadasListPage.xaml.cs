using CashDriver.ViewModels;
using CommunityToolkit.Maui.Core;
using CommunityToolkit.Maui.Core.Platform;

namespace CashDriver.Views;

public partial class JornadasListPage : ContentPage
{
	public JornadasListPage(JornadasListViewModel vm)
	{
		InitializeComponent();
        BindingContext = vm;
	}
}