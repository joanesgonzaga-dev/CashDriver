using CashDriver.ViewModels;
using CommunityToolkit.Maui.Core;
using CommunityToolkit.Maui.Core.Platform;

namespace CashDriver.Views;

public partial class JornadaPage : ContentPage
{
	public JornadaPage(JornadaViewModel vm)
	{
		InitializeComponent();
        StatusBar.SetColor(Color.FromArgb("#071B34"));
        StatusBar.SetStyle(StatusBarStyle.LightContent);
        BindingContext = vm;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        if (BindingContext is JornadaViewModel vm)
        {
            vm.CarregarDadosJornada();
        }
    }
}