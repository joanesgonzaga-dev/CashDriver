﻿using CashDriver.Models;
using CashDriver.Models.Enums;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CashDriver.Services
{
    public class JornadaService
    {
        public Jornada? JornadaAtual { get; private set; }
        public ObservableCollection<Ganho> GanhosLancados { get; } = new();
        public ObservableCollection<TipoDespesa> CadastroDeDespesas { get; } = new();
        public ObservableCollection<Meta> CadastroDeMetas { get; } = new();
        public ObservableCollection<Despesa> DespesasLancadas { get; } = new();
        public ObservableCollection<Plataforma> CadastroDePlataformas { get; } = new();

        public JornadaService()
        {
            // Inicializa uma única vez

            //Plataformas
            CadastroDePlataformas.Add(new Plataforma { Name = "Uber"});
            CadastroDePlataformas.Add(new Plataforma { Name = "99 pop" });
            CadastroDePlataformas.Add(new Plataforma { Name = "inDrive" });
            CadastroDePlataformas.Add(new Plataforma { Name = "Maxim" });

            //Metas
            CadastroDeMetas.Add(new Meta { Nome = "Aluguel", ValorMeta = 2287, ValorAtual = 1200 });
            CadastroDeMetas.Add(new Meta { Nome = "Meta diária", ValorMeta = 200, ValorAtual = 75.80M });
            CadastroDeMetas.Add(new Meta { Nome = "Combustível", ValorMeta = 100, ValorAtual = 60 });

            //Despesas
            CadastroDeDespesas.Add(new TipoDespesa { DescricaoTipo = "Combustível", Tipo = EnumTipoDespesa.Combustivel, NomeIcone = string.Empty });
            CadastroDeDespesas.Add(new TipoDespesa { DescricaoTipo = "Alimentação", Tipo = EnumTipoDespesa.Alimentacao, NomeIcone = string.Empty });
            CadastroDeDespesas.Add(new TipoDespesa { DescricaoTipo = "Manutenção", Tipo = EnumTipoDespesa.Manutencao, NomeIcone = string.Empty });
            CadastroDeDespesas.Add(new TipoDespesa { DescricaoTipo = "Limpeza/Higienização" , Tipo = EnumTipoDespesa.Limpeza, NomeIcone = string.Empty });
            CadastroDeDespesas.Add(new TipoDespesa { DescricaoTipo = "Diversos" , Tipo = EnumTipoDespesa.Diversos, NomeIcone = string.Empty });

        }

        public void IniciarJornada()    
        {
            JornadaAtual = new Jornada
            {
                Inicio = DateTime.Now,
                TotalGanhos = 0,
                TotalDespesas = 0,
                Status = Models.Enums.EnumStatusJornada.Ativa,
                Ganhos = GanhosLancados,
                Metas = CadastroDeMetas,
                Despesas = DespesasLancadas,
                Plataformas = CadastroDePlataformas
            };
        }

        public void EncerrarJornada()
        {
            //Persistir neste momento
            JornadaAtual = null;
        }
    }
}
