﻿using CashDriver.Models.Enums;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;

namespace CashDriver.Models
{
    public partial class Jornada : ObservableObject
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public DateTime Inicio { get; set; }
        public DateTime? Termino { get; set; }
        public decimal TotalGanhos { get; set; }
        public decimal TotalDespesas { get; set; }

        [ObservableProperty]
        public EnumStatusJornada status = EnumStatusJornada.Inativa;
        public ObservableCollection<Meta> Metas { get; set; } = new();
        public ObservableCollection<Despesa> Despesas { get; set; } = new();
        public ObservableCollection<Ganho> Ganhos { get; set; } = new();
        public ObservableCollection<Plataforma> Plataformas { get; set; } = new();
        public TimeSpan Duracao => (Termino ?? DateTime.Now) - Inicio;
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }
        public EnumSyncStatus SyncStatus { get; set; }
    }
}
