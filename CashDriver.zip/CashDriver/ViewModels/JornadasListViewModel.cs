﻿using CashDriver.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using System.Collections.ObjectModel;

namespace CashDriver.ViewModels
{
    public partial class JornadasListViewModel : ObservableObject
    {
        JornadaService _jornadaService;

        public ObservableCollection<string> Jornadas { get; set; } = new();

        public JornadasListViewModel(JornadaService jornadaService)
        {
            _jornadaService = jornadaService;
            montaLista();
        }

        public void montaLista()
        {
            Jornadas.Add("item1");
            Jornadas.Add("item2");
            Jornadas.Add("item3");
            Jornadas.Add("item4");
            Jornadas.Add("item5");
            Jornadas.Add("item6");
            Jornadas.Add("item7");
            Jornadas.Add("item8");

        }
    }
}
