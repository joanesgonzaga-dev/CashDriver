﻿using CashDriver.Models;
using CashDriver.Models.Enums;
using CashDriver.Services;
using CashDriver.Views;
using CashDriver.Views.Popups;
using CommunityToolkit.Maui.Views;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;

namespace CashDriver.ViewModels
{
    public partial class JornadaViewModel : ObservableObject
    {
        private readonly JornadaService _jornadaService;

        [ObservableProperty]
        private Jornada? jornadaAtual;

        public bool Ativa => JornadaAtual?.Status == EnumStatusJornada.Ativa;

        public bool Inativa => JornadaAtual == null || JornadaAtual?.Status == EnumStatusJornada.Inativa;

        private System.Timers.Timer _timer;

        public decimal TotalGanhos => _jornadaService.GanhosLancados.Sum(g => g.Valor);

        public decimal TotalDespesas => _jornadaService.DespesasLancadas.Sum(d => d.Valor);

        public decimal Lucro => TotalGanhos - TotalDespesas;

        [ObservableProperty]
        private ObservableCollection<Meta> metas = new();

        public ObservableCollection<ExtratoItem> Extrato { get; } = new();

        public bool TemLancamentos => Extrato?.Any() == true;

        public bool TemMetas => Metas?.Any() == true;

        public JornadaViewModel(JornadaService jornadaService)
        {
            _jornadaService = jornadaService;
            JornadaAtual = _jornadaService.JornadaAtual;

            #region contabiliza e atualiza tempo na tela
            _timer = new System.Timers.Timer(1000);
            _timer.Elapsed += (s, e) =>
            {
                MainThread.BeginInvokeOnMainThread(() =>
                {
                    OnPropertyChanged(nameof(TempoJornadaFormatado));
                });
            };
            _timer.Start();
            #endregion


            #region registro de eventos
            // Notifica a UI que TemLancamentos mudou sempre que a coleção Extrato for alterada
            // (Add, Remove, Clear, etc. disparam CollectionChanged)

            // Este evento é registrado apenas uma vez no construtor,
            // evitando múltiplas inscrições e execução duplicada

            // Mantém a lógica centralizada:
            // a atualização de TemLancamentos não precisa ser chamada manualmente em vários pontos do código
            Extrato.CollectionChanged += (s, e) =>
            {
                OnPropertyChanged(nameof(TemLancamentos));
            };

            
            Metas.CollectionChanged += (s, e) =>
            {
                OnPropertyChanged(nameof(TemMetas));
            };
            #endregion
        }

        partial void OnJornadaAtualChanged(Jornada? value)
        {
            if (value is not null)
            {
                value.PropertyChanged += JornadaAtual_PropertyChanged;
            }

            OnPropertyChanged(nameof(Ativa));
            OnPropertyChanged(nameof(Inativa));
        }

        private void JornadaAtual_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(Jornada.Status))
            {
                OnPropertyChanged(nameof(Ativa));
                OnPropertyChanged(nameof(Inativa));
                // ou qualquer outra propriedade dependente
            }
        }

        //partial void OnTotalGanhosChanged(decimal value)
        //{
        //    OnPropertyChanged(nameof(Lucro));
        //}

        //partial void OnDespesasChanged(decimal value)
        //{
        //    OnPropertyChanged(nameof(Lucro));
        //    //não é boa prática deixar ViewModel chamar UI diretamente
        //    //O ideal é usar serviço de diálogo ou mensageria
        //    //Mas para agora(wireframe), perfeito para testar comportamento
        //    MainThread.BeginInvokeOnMainThread(async () =>
        //    {
        //        await Application.Current.MainPage.DisplayAlert(
        //            "Lucro atualizado",
        //            $"Novo lucro: R$ {Lucro:F2}",
        //            "OK");
        //    });
        //}

        [RelayCommand]
        private async Task AdicionarDespesa()
        {

            if (!Ativa)
            {
                await Shell.Current.DisplayAlert("Alerta!", "Não existe jornada Ativa para lançar a despesa\nInicie uma Jornada!", "OK");
                return;
            }

            LancarDespesaPopup? popup = null;
            var vm = new LancarDespesaPopupViewModel(
                _jornadaService,
                () => popup?.Close());

            popup = new LancarDespesaPopup(vm);

            await Shell.Current.CurrentPage.ShowPopupAsync(popup);
            OnPropertyChanged(nameof(TotalDespesas));
            OnPropertyChanged(nameof(TotalGanhos));
            OnPropertyChanged(nameof(Lucro));
            OnPropertyChanged(nameof(TemLancamentos));
            OnPropertyChanged(nameof(Extrato));
            MontarExtrato();
        }

        [RelayCommand]
        private async Task AdicionarGanho()
        {

            if (!Ativa)
            {
                await Shell.Current.DisplayAlert("Alerta!", "Não existe jornada Ativa para lançar ganhos\nInicie uma Jornada!", "OK");
                return;
            }

            LancarGanhoPopup? popup = null;
            var vm = new LancarGanhoPopupViewModel(
                _jornadaService,
                () => popup?.Close());

            popup = new LancarGanhoPopup(vm);

            await Shell.Current.CurrentPage.ShowPopupAsync(popup);
            OnPropertyChanged(nameof(TotalDespesas));
            OnPropertyChanged(nameof(Lucro));
            OnPropertyChanged(nameof(TemLancamentos));
            OnPropertyChanged(nameof(Extrato));
            MontarExtrato();
        }

        [RelayCommand]
        private async void EncerrarJornada()
        {
            // Simular Encerrar Jornada
            await Application.Current.MainPage.DisplayAlert(
                "Jornada",
                "Jornada encerrada!",
                "OK");
        }

        [RelayCommand]
        private async Task CriarMetaRapido()
        {
            await Shell.Current.GoToAsync(nameof(CriarMetaPage));
        }


        [RelayCommand]
        private async Task IniciarJornada()
        {
            if (_jornadaService.JornadaAtual != null && _jornadaService.JornadaAtual.Status == Models.Enums.EnumStatusJornada.Ativa)
            {
                await Application.Current.MainPage.DisplayAlert(
                    "Jornada",
                    $"Já existe uma Jornada iniciada!",
                    "OK"
                    );
            }

            else
            {
                _jornadaService.IniciarJornada();
                JornadaAtual = _jornadaService.JornadaAtual;
            }

            //navegar
            await Shell.Current.GoToAsync("//Jornada"); // //Page só funciona se os ShellContent em AppShell.xaml tiverem o atributo Route="SuaPage"
            CarregarDadosJornada();
        }

        public string TempoJornadaFormatado
        {
            get
            {
                var jornada = _jornadaService.JornadaAtual;

                if (jornada == null)
                    return "00:00:00";
                return jornada.Duracao.ToString(@"hh\:mm\:ss");
            }
        }

        public void CarregarDadosJornada()
        {
            JornadaAtual = _jornadaService.JornadaAtual;

            if (JornadaAtual != null)
            {
                //TotalGanhos = JornadaAtual.TotalGanhos;
                //ESSA LINHA É A CHAVE
                //OnPropertyChanged(nameof(Metas));
                OnPropertyChanged(nameof(TempoJornadaFormatado));
                OnPropertyChanged(nameof(Ativa));
                OnPropertyChanged(nameof(Inativa));
                OnPropertyChanged(nameof(TotalDespesas));
                OnPropertyChanged(nameof(TotalGanhos));
                MontarExtrato();
                CarregarMetas();
            }
        }

        private void MontarExtrato()
        {
            Extrato.Clear();

            //Ganhos
            foreach (var ganho in _jornadaService.GanhosLancados)
            {
                Extrato.Add(new ExtratoItem
                {
                    Id = Guid.NewGuid(),
                    LancamentoId = ganho.Id,
                    Tipo = Models.Enums.EnumTipoExtrato.Ganho,
                    Descricao = ganho.PlataformaNome,
                    Valor = ganho.Valor,
                    ValorTexto = $"+ {ganho.Valor.ToString("C", new CultureInfo("pt-BR"))}",
                    ValorColor = Color.FromArgb("#19C37D"),
                    Data = ganho.CreatedAt
                });
            }

            //Despesas
            foreach (var despesa in _jornadaService.DespesasLancadas)
            {
                Extrato.Add(new ExtratoItem
                {
                    Id = Guid.NewGuid(),
                    LancamentoId = despesa.Id,
                    Tipo = Models.Enums.EnumTipoExtrato.Despesa,
                    Descricao = despesa.NomeTipo,
                    Valor = despesa.Valor,
                    ValorTexto = $"- {despesa.Valor.ToString("C", new CultureInfo("pt-BR"))}",
                    ValorColor = Color.FromArgb("#FF4500"),
                    Data = despesa.CreatedAt
                });
            }

            //Metas
            //foreach (var meta in Metas)
            //{
            //    Extrato.Add(new ExtratoItem
            //    {
            //        Tipo = Models.Enums.EnumTipoExtrato.Meta,
            //        Descricao = meta.Nome,
            //        Valor = meta.ValorMeta,
            //        Data = meta.DataFim,
            //        Progresso = meta.Progresso
            //    });
            //}

            // Ordenar por data
            var ordenado = Extrato.OrderByDescending(x => x.Data).ToList();

            Extrato.Clear();
            foreach (var item in ordenado)
                Extrato.Add(item);
            OnPropertyChanged(nameof(TotalGanhos));
            OnPropertyChanged(nameof(Extrato));
        }

        public void CarregarMetas()
        {
            Metas.Clear();
            foreach (var meta in _jornadaService.JornadaAtual?.Metas.Where(m => m.Selecionada) ?? Enumerable.Empty<Meta>())
            {
                Metas.Add(meta);
            }
        }

        [RelayCommand]
        public async Task Mostrar()
        {
            await Application.Current.MainPage.DisplayAlert("OK", $"{Ativa}", "OK");
        }

        [RelayCommand]
        public async Task DeletarLancamentoExtrato(ExtratoItem item)
        {
            var result = await Application.Current.MainPage.DisplayAlert(
                "Exxcluir",
                "Confirma a exclusão do lançamento?",
                "SIM",
                "NÃO");

            if (!result)
            {
                return;
            }


            if (item.Tipo == EnumTipoExtrato.Ganho)
            {
                var ganho = _jornadaService.GanhosLancados.First(g => g.Id == item.LancamentoId);
                _jornadaService.GanhosLancados.Remove(ganho);
                Extrato.Remove(item);
                MontarExtrato();
                OnPropertyChanged(nameof(Lucro));
            }

            else if (item.Tipo == EnumTipoExtrato.Despesa)
            {
                var despesa = _jornadaService.DespesasLancadas.First(d => d.Id == item.LancamentoId);
                _jornadaService.DespesasLancadas.Remove(despesa);
                Extrato.Remove(item);
                MontarExtrato();
                OnPropertyChanged(nameof(Lucro));
            }
        }
    }
}
