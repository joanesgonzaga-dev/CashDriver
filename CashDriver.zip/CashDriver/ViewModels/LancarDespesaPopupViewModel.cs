﻿using CashDriver.Models;
using CashDriver.Models.Enums;
using CashDriver.Services;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CashDriver.ViewModels
{
    public partial class LancarDespesaPopupViewModel : ObservableObject
    {

        [ObservableProperty]
        private decimal valor;

        [ObservableProperty]
        private string nome;

        [ObservableProperty]
        private string observacoes;

        [ObservableProperty]
        private ObservableCollection<TipoDespesa> tiposDeDespesas = new();

        [ObservableProperty]
        private TipoDespesa tipoDespesaSelecionada;

        private readonly JornadaService _jornadaService;

        private readonly Action _fechar;

        public LancarDespesaPopupViewModel(JornadaService jornadaService, Action fechar)
        {
            _jornadaService = jornadaService;
            _fechar = fechar;

            CarregarTiposDeDespesas();
        }

        [RelayCommand]
        private async Task Lancar()
        {
            if (Valor <= 0M)
            {
                await Shell.Current.DisplayAlert("Atenção", "Informe um valor válido!", "OK");
                return;
            }

            var despesa = new Despesa
            {
                JornadaId = _jornadaService?.JornadaAtual?.Id,
                NomeTipo = TipoDespesaSelecionada.DescricaoTipo,
                Detalhes = Observacoes,
                Tipo = TipoDespesaSelecionada,
                Valor = Valor,
                CreatedAt = DateTime.Now
            };

            _jornadaService?.DespesasLancadas.Add(despesa);
            _fechar.Invoke();
        }


        public void CarregarTiposDeDespesas()
        {
            TiposDeDespesas.Clear();
            foreach (var tipoDespesa in _jornadaService.CadastroDeDespesas ?? Enumerable.Empty<TipoDespesa>())
            {
                TiposDeDespesas.Add(tipoDespesa);
            }
        }
    }
}
